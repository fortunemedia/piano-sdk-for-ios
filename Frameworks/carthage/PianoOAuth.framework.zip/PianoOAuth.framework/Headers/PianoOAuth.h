#import <UIKit/UIKit.h>

//! Project version number for PianoOAuth.
FOUNDATION_EXPORT double PianoOAuthVersionNumber;

//! Project version string for PianoOAuth.
FOUNDATION_EXPORT const unsigned char PianoOAuthVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <PianoOAuth/PublicHeader.h>


